package com.example.stockspring.controller;

import org.springframework.web.servlet.ModelAndView;

public interface SPriceController {

	public ModelAndView getPriceList() throws Exception;
}
